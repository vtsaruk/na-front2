function generateArray() {
	var data = [];
	for (var i = 0; i < 10; i++) data.push(Math.random() * 100);
	return data;
}

function generateData() {
	var data = [];
	for (var i = 0; i < 10; i++) {
		data.push({
			value: 'value' + i,
			label: 'label' + i
		});
	}
	return data;
}

function generateGroupData() {
	var data = {};
	for (var i = 0; i < 10; i++) {
		var group = [];
		for (var j = 0; j < 10; j++) {
			group.push({
				value: 'value' + i + j,
				label: 'label' + i + j
			});
		}
		data['group' + i] = group;
	}
	return data;
}

$(function () {

	// simple array data
	$('#select0').JQSelect({
		multi: false,
		group: false,
		hideFilter: true,
		hideOKButton: true,
		hideCloseButton: true,
		data: generateArray(),
		onSelect: function (selectItems) {
			console.log('onSelect: ', selectItems);
		},
		onDeselect: function (selectItems) {
			console.log('onDeselect: ', selectItems);
		},
		onChange: function (value) {
			console.log('onChange: ', value);
		},
		onOK: function () {
			console.log('onOK');
		},
		onClose: function () {
			console.log('onClose');
		}
	});

	// single
	$('#select1').JQSelect({
		multi: false,
		group: false,
		hideFilter: true,
		hideOKButton: true,
		hideCloseButton: true,
		data: generateData(),
		onSelect: function (selectItems) {
			console.log('onSelect: ', selectItems);
		},
		onDeselect: function (selectItems) {
			console.log('onDeselect: ', selectItems);
		},
		onChange: function (value) {
			console.log('onChange: ', value);
		},
		onOK: function () {
			console.log('onOK');
		},
		onClose: function () {
			console.log('onClose');
		}
	});

	// single / group
	$('#select2').JQSelect({
		multi: false,
		group: true,
		hideFilter: true,
		hideOKButton: true,
		hideCloseButton: true,
		data: generateGroupData(),
		onSelect: function (selectItems) {
			console.log('onSelect: ', selectItems);
		},
		onDeselect: function (selectItems) {
			console.log('onDeselect: ', selectItems);
		},
		onChange: function (value) {
			console.log('onChange: ', value);
		},
		onOK: function () {
			console.log('onOK');
		},
		onClose: function () {
			console.log('onClose');
		}
	});

	// multi
	$('#select3').JQSelect({
		multi: true,
		group: false,
		hideFilter: true,
		hideOKButton: true,
		hideCloseButton: true,
		data: generateData(),
		onSelect: function (selectItems) {
			console.log('onSelect: ', selectItems);
		},
		onDeselect: function (selectItems) {
			console.log('onDeselect: ', selectItems);
		},
		onChange: function (value) {
			console.log('onChange: ', value);
		},
		onOK: function () {
			console.log('onOK');
		},
		onClose: function () {
			console.log('onClose');
		}
	});

	// multi / group
	$('#select4').JQSelect({
		multi: true,
		group: true,
		hideFilter: true,
		hideOKButton: true,
		hideCloseButton: true,
		data: generateGroupData(),
		onSelect: function (selectItems) {
			console.log('onSelect: ', selectItems);
		},
		onDeselect: function (selectItems) {
			console.log('onDeselect: ', selectItems);
		},
		onChange: function (value) {
			console.log('onChange: ', value);
		},
		onOK: function () {
			console.log('onOK');
		},
		onClose: function () {
			console.log('onClose');
		}
	});

	// single / loading / buttons
	$('#select5').JQSelect().trigger('loadingStart');
	setTimeout(function () {
		$('#select5').JQSelect({
			data: generateData(),
			hideFilter: true,
			hideSelectAll: true,
			onSelect: function (selectItems) {
				console.log('onSelect: ', selectItems);
			},
			onDeselect: function (selectItems) {
				console.log('onDeselect: ', selectItems);
			},
			onChange: function (value) {
				console.log('onChange: ', value);
			},
			onOK: function () {
				console.log('onOK');
			},
			onClose: function () {
				console.log('onClose');
			}
		}).trigger('updateOptions').trigger('loadingEnd');
	}, 2000);

	// multi / group / buttons / loading
	$('#select6').JQSelect().trigger('loadingStart');
	setTimeout(function () {
		$('#select6').JQSelect({
			multi: true,
			group: true,
			data: generateGroupData(),
			hideFilter: true,
			hideSelectAll: true,
			onSelect: function (selectItems) {
				console.log('onSelect: ', selectItems);
			},
			onDeselect: function (selectItems) {
				console.log('onDeselect: ', selectItems);
			},
			onChange: function (value) {
				console.log('onChange: ', value);
			},
			onOK: function () {
				console.log('onOK');
			},
			onClose: function () {
				console.log('onClose');
			}
		}).trigger('updateOptions').trigger('loadingEnd');
	}, 2000);

	// multi / group / filter / select all
	$('#select7').JQSelect({
		multi: true,
		group: true,
		data: generateGroupData(),
		hideOKButton: true,
		hideCloseButton: true,
		onSelect: function (selectItems) {
			console.log('onSelect: ', selectItems);
		},
		onDeselect: function (selectItems) {
			console.log('onDeselect: ', selectItems);
		},
		onChange: function (value) {
			console.log('onChange: ', value);
		},
		onOK: function () {
			console.log('onOK');
		},
		onClose: function () {
			console.log('onClose');
		}
	});

	// icon
	$('#select8').JQSelect({
		data: generateArray(),
		iconCls: 'fa fa-circle-thin',
		hideFilter: true,
		hideOKButton: true,
		hideCloseButton: true,
		onSelect: function (selectItems) {
			console.log('onSelect: ', selectItems);
		},
		onDeselect: function (selectItems) {
			console.log('onDeselect: ', selectItems);
		},
		onChange: function (value) {
			console.log('onChange: ', value);
		},
		onOK: function () {
			console.log('onOK');
		},
		onClose: function () {
			console.log('onClose');
		}
	});

	// updateOptions
	function updateSelect(data) {
		$('#select9').JQSelect({
			data: data,
			iconCls: 'fa fa-circle-thin',
			hideFilter: true,
			hideOKButton: true,
			hideCloseButton: true,
			onSelect: function (selectItems) {
				console.log('onSelect: ', selectItems);
			},
			onDeselect: function (selectItems) {
				console.log('onDeselect: ', selectItems);
			},
			onChange: function (value) {
				console.log('onChange: ', value);
			},
			onOK: function () {
				console.log('onOK');
			},
			onClose: function () {
				console.log('onClose');
			}
		}).trigger('updateOptions');
	}

	updateSelect(generateArray());
	setTimeout(function () {
		updateSelect(generateArray());
		console.log('select9 updated');
	}, 2000);

});